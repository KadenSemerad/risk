The .NET application is currently deployed and live on Azure so no deployment is necessary.

To run locally, run 'dotnet watch run' in the terminal and change the frotned base URL to your localhost URL.
