﻿namespace risk.ViewModels;

public class PasswordResetRequestViewModel
{
    public string Email { get; set; } = string.Empty;
}