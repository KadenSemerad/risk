namespace risk.ViewModels;

public class DeleteAccountViewModel
{
    public string UserId { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;
}